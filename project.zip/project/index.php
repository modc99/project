<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
<style>
    body {
    background-image: url("img/bg.png");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
}
</style>
    <div class="container">
        <h3 class="mt-4">ເຂົ້າສູ້ລະບົບ</h3>
        <hr>
        <form action="signin_db.php" method="post">
            <?php if(isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger" role="alert">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php } ?>
            <?php if(isset($_SESSION['success'])) { ?>
                <div class="alert alert-success" role="alert">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php } ?>
            <div class="mb-3">
                <label for="username" class="form-label">ຊື່ຜູ້ໃຊ້</label>
                <input type="text" class="form-control" name="username" aria-describedby="username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">ລະຫັດຜ່ານ</label>
                <input type="password" class="form-control" name="password" id="password">
            </div>
            <div class="mb-3">
            <input type="checkbox" class="ui-checkbox" id="togglePassword">
            </div>
            <button type="submit" name="signin" class="btn btn-primary">ເຂົ້າສູ້ລະບົບ</button>
        </form>
        <hr>
        <p>ຍັງບໍໄດ້ສະມັກ ກົດ <a href="signug.php">ສະມັກສະມາຊີກ</a></p>
        
    </div>

</body>
    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function() {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.textContent = type === 'password' ? 'ໂຊລະຫັດ' : 'ຊ່ອນ';
        });
    </script>
</html>
