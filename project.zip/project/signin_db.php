<?php
session_start();
require_once 'config/db.php';

if (isset($_POST['signin'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username)) {
        $_SESSION['error'] = 'ກະລຸນາໃສ່ຊື່ຜູ້ໃຊ້';
        header("location: index.php");
    } else if (empty($password)) {
        $_SESSION['error'] = 'ກະລຸນາໃສ່ລະຫັດຜ່ານ';
        header("location: index.php");
    } else if (strlen($_POST['password']) > 20 || strlen($_POST['password']) < 8) {
        $_SESSION['error'] = 'ລະຫັດຜ່ານຕ້ອງມີຄວາມຍາວ 8 ຫາ 20 ໂຕ';
        header("location: index.php");
    } else {
        try {
            $check_data = $conn->prepare("SELECT * FROM users WHERE username = :username");
            $check_data->bindParam(":username", $username);
            $check_data->execute();
            $row = $check_data->fetch(PDO::FETCH_ASSOC);

            if ($check_data->rowCount() > 0) {
                if (password_verify($password, $row['password'])) {
                    if ($row['urole'] == 'admin') {
                        $_SESSION['admin_login'] = $row['id'];
                        header("location: admin.php");
                    } else {
                        $_SESSION['user_login'] = $row['id'];
                        header("location: home.php");
                    }
                } else {
                    $_SESSION['error'] = 'ລະຫັດບໍຖືກ';
                    header("location: index.php");
                }
            } else {
                $_SESSION['error'] = 'ຊື່ຜູ້ໃຊ້ບໍຖືກ';
                header("location: index.php");
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}
?>
