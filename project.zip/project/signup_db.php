<?php
session_start();
require_once 'config/db.php';

if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];
    $urole = 'user';

    if (empty($username)) {
        $_SESSION['error'] = 'ກະລຸນາໃສ່ຊື່ຜູ້ໃຊ້';
        header("location: signug.php");
    } else if (empty($email)) {
        $_SESSION['error'] = 'ກະລຸນາໃສ່ອີເມວ';
        header("location: signug.php");
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'ຮູບແບບອີເມວບໍຖືກຕ້ອງ';
        header("location: signug.php");
    } else if (empty($password)) {
        $_SESSION['error'] = 'ກະລຸນາໃສ່ລະຫັດຜ່ານ';
        header("location: signug.php");
    } else if (strlen($password) > 20 || strlen($password) < 8) {
        $_SESSION['error'] = 'ລະຫັດຜ່ານຕ້ອງມີຄວາມຍາວ 8 ຫາ 20 ໂຕ';
        header("location: signug.php");
    } else if (empty($c_password)) {
        $_SESSION['error'] = 'ກະລຸນາຢືນຢັນລະຫັດຜ່ານອີກຄັ້ງ';
        header("location: signug.php");
    } else if ($password != $c_password) {
        $_SESSION['error'] = 'ລະຫັດຜ່ານບໍຕົງກັນ';
        header("location: signug.php");
    } else {
        try {
            // Check if the email already exists
            $check_email = $conn->prepare("SELECT email FROM users WHERE email = :email");
            $check_email->bindParam(":email", $email);
            $check_email->execute();
    
            if ($check_email->rowCount() > 0) {
                $_SESSION['warning'] = "ມີອີເມວຢູ່ແລ້ວ";
                header("location: index.php"); // Change this redirect location if needed
                exit;
            }
    
            // Check if the username already exists
            $check_username = $conn->prepare("SELECT username FROM users WHERE username = :username");
            $check_username->bindParam(":username", $username);
            $check_username->execute();
    
            if ($check_username->rowCount() > 0) {
                $_SESSION['warning'] = "ຊື່ຜ້າໃຊ້ມີແລ້ວໃສ່ແບບອື່ນ";
                header("location: signug.php");
                exit;
            }
    
            // Hash the password
            $password = password_hash($password, PASSWORD_DEFAULT);
    
            // Insert the new user into the database
            $stmt = $conn->prepare("INSERT INTO users(username, email, password, urole) VALUES(:username, :email, :password, :urole)");
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":password", $password);
            $stmt->bindParam(":urole", $urole);
            $stmt->execute();
    
            $_SESSION['success'] = "ສະມັກສະມາຊີກສຳເລັດ";
            header("location: index.php"); // Change this redirect location if needed
            exit;
    
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    
    }
}
?>
